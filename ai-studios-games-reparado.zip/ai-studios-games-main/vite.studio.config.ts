import { defineConfig } from "vite";

// Build the studio website from the repository root. Game assets and the RPG
// live in /public and are copied as-is into the production output.
export default defineConfig({
  root: ".",
  base: "./",
  publicDir: "public",
  build: {
    outDir: "dist",
    emptyOutDir: true,
    assetsDir: "studio-assets",
    rollupOptions: { input: "index.html" },
  },
});
