# Recuperação do site e dos jogos

## O que foi corrigido nesta revisão

- A página inicial agora carrega o site principal AI Studios Games (`src/main.ts`) em vez da antiga página do Slither.Idle.
- A antiga página de apresentação do Slither foi preservada em `slither-idle.html`.
- Foi adicionada uma configuração Vite própria para compilar o site principal sem conflitar com o cliente Bomber Idle.
- Foi adicionado um workflow do GitHub Actions para publicar o site no GitHub Pages quando houver push em `main` ou `master`.
- O workflow publica o Bomber Idle em `/bomber-idle/` e os arquivos do Slither Idle em `/slither-idle/`, conforme os endereços usados pelo catálogo.

## Como publicar

1. Envie estas alterações para o repositório GitHub que contém o projeto.
2. Em **Settings → Pages**, escolha **GitHub Actions** como origem de publicação.
3. Abra **Actions** e acompanhe a execução de “Deploy AI Studios Games to GitHub Pages”.
4. Se a execução falhar, abra o primeiro passo vermelho e consulte a mensagem de erro.

## Importante

A revisão local encontrou uma instalação incompleta das dependências no ambiente de análise; por isso não foi possível confirmar uma compilação de produção nem executar toda a suíte de testes aqui. O workflow instala as dependências do zero e faz a compilação no GitHub antes de publicar.

O jogo Bomber Idle permanece em modo demo até que a API e os componentes on-chain estejam corretamente implantados e configurados. O workflow do site não implanta nem corrige serviços externos, DNS, domínio personalizado, Cloudflare Worker, banco D1 ou programa Solana. Se o site estiver hospedado fora do GitHub Pages, o workflow precisa ser adaptado ao provedor de hospedagem.
